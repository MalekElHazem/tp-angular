export class Voiture {
    public id: number;
    public title: string;
    public des: string;
    public date: Date;
    constructor(id:number, title:string, des:string, date:Date) { 
        this.id = id;
        this.title = title;
        this.des = des;
        this.date = date;
    }
}