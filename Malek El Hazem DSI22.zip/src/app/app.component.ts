import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { VoitureService } from './voiture.service';
import { Voiture } from './model/voiture';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'exam';
  voitureForm: FormGroup = this.fb.group({ voitures: this.fb.array([]) });


  constructor(private fb: FormBuilder, private voitureService: VoitureService) {}

  ngOnInit() {
      this.voitureService.getVoiture().subscribe((voitures: Voiture[]) => {
      this.voitureForm.setControl('voitures', this.fb.array(voitures || []));
    });
  }

  onSubmit() {
    console.log(this.voitureForm.value);
  }
}

