import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Voiture } from './model/voiture';

@Injectable({
  providedIn: 'root'
})
export class VoitureService {




  constructor(private http: HttpClient) { }
  public getVoiture(): Observable<Voiture[]>
  {
    const url = 'http://localhost:3000/voiture';
    return this.http.get<Voiture[ ]>(url);
  }
  public addVoiture(Voiture: Voiture): Observable<any>
  {
    const url = 'http://localhost:3000/voiture';
    return this.http.post(url, Voiture);
  }
  
  public deleteVoiture(id: number): Observable<any>
  {
    const url = 'http://localhost:3000/voiture/' + id;
    return this.http.delete(url);
  }
  public updateVoiture(Voiture: Voiture): Observable<any>
  {
    const url = 'http://localhost:3000/voiture/' + Voiture.id;
    return this.http.put(url, Voiture);
  }

  getVoitureById(id: any){
    const url = 'http://localhost:3000/voiture/' + id;
    return this.http.get(url);
  }
}
